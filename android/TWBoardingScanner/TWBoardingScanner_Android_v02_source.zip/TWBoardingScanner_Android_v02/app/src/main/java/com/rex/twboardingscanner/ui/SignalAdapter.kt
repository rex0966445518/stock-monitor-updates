package com.rex.twboardingscanner.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rex.twboardingscanner.databinding.ItemStockSignalBinding
import com.rex.twboardingscanner.domain.SignalLight
import com.rex.twboardingscanner.domain.SignalResult

class SignalAdapter: RecyclerView.Adapter<SignalAdapter.VH>() {
    private val items = mutableListOf<SignalResult>()
    fun submit(list: List<SignalResult>) { items.clear(); items.addAll(list); notifyDataSetChanged() }

    class VH(val b: ItemStockSignalBinding): RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(ItemStockSignalBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        val s = r.snapshot
        val type = if (r.radarType.name.startsWith("A_")) "A型起漲" else "B型深跌反轉"
        val light = when(r.light) {
            SignalLight.RED -> "🔴"
            SignalLight.ORANGE -> "🟠"
            SignalLight.YELLOW -> "🟡"
            SignalLight.WEAKENING -> "⚠️"
            else -> "⚪"
        }
        h.b.title.text = "$light $type｜${s.code} ${s.name}   ${s.price} (${s.changePct}%)"
        h.b.score.text = "${s.sector.label}｜AI符合度：${r.score}%"
        h.b.details.text = "MACD DIF ${s.dif ?: "待更新"} / Signal ${s.signal ?: "待更新"} / OSC ${s.osc ?: "待更新"}\n" +
            "RSI ${s.rsi ?: "待更新"}｜MA5 ${s.ma5 ?: "-"}｜MA10 ${s.ma10 ?: "-"}｜MA20 ${s.ma20 ?: "-"}\n" +
            "量 ${s.volumeLots}張｜20日均量 ${s.avg20VolumeLots.toInt()}張｜外資3日 ${s.foreign3d ?: "待更新"}｜投信3日 ${s.trust3d ?: "待更新"}"
        h.b.trigger.text = "觸發原因：${if (r.reasons.isEmpty()) "尚未達門檻" else r.reasons.joinToString("＋")}" +
            (if (r.blockers.isNotEmpty()) "\n阻擋：${r.blockers.joinToString("；")}" else "")

        if (r.light == SignalLight.RED) {
            h.b.root.animate().alpha(0.55f).setDuration(350).withEndAction {
                h.b.root.animate().alpha(1f).setDuration(350).start()
            }.start()
        }
    }
}
