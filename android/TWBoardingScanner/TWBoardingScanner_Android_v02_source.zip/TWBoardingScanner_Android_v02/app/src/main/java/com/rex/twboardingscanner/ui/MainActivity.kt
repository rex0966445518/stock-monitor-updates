package com.rex.twboardingscanner.ui

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.rex.twboardingscanner.R
import com.rex.twboardingscanner.data.DemoDataProvider
import com.rex.twboardingscanner.data.SignalHistoryDb
import com.rex.twboardingscanner.databinding.ActivityMainBinding
import com.rex.twboardingscanner.domain.ScoringEngine
import com.rex.twboardingscanner.domain.SignalLight
import com.rex.twboardingscanner.domain.SignalResult
import com.rex.twboardingscanner.domain.StockSector
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity: AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val adapter = SignalAdapter()
    private val engine = ScoringEngine()
    private val provider = DemoDataProvider()
    private lateinit var history: SignalHistoryDb
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var latest = listOf<SignalResult>()
    private var selectedTab = 0
    private val prefs by lazy { getSharedPreferences("scanner_filters", MODE_PRIVATE) }
    private var enabledSectors: MutableSet<StockSector> = mutableSetOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        history = SignalHistoryDb(this)
        createNotificationChannel()
        askNotificationPermission()
        loadIndustryFilter()

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.industryFilterButton.setOnClickListener { showIndustryFilterDialog() }
        updateIndustryFilterButton()
        b.recycler.adapter = adapter
        listOf("今日新觸發", "A｜起漲", "B｜深跌", "等待區", "已失效").forEach { b.tabLayout.addTab(b.tabLayout.newTab().setText(it)) }
        b.tabLayout.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) { selectedTab = tab?.position ?: 0; render() }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        startScanLoop()
    }

    private fun startScanLoop() {
        handler.post(object: Runnable {
            override fun run() {
                runScan()
                handler.postDelayed(this, 60_000L) // MVP: every 60s while app is open
            }
        })
    }

    private fun runScan() {
        val source = provider.load()
        val filteredSource = source.filter { it.sector in enabledSectors }
        val all = filteredSource.flatMap { s -> listOf(engine.evaluateA(s), engine.evaluateB(s)) }
        latest = all
        var newTriggers = 0
        all.filter { it.light != SignalLight.NONE }.forEach { r ->
            if (history.insertIfNew(r)) {
                newTriggers++
                if (r.light == SignalLight.RED || r.light == SignalLight.ORANGE) notifyNewSignal(r)
            }
        }
        val now = SimpleDateFormat("HH:mm:ss", Locale.TAIWAN).format(Date())
        val aCount = all.count { it.radarType.name.startsWith("A_") && it.light != SignalLight.NONE }
        val bCount = all.count { it.radarType.name.startsWith("B_") && it.light != SignalLight.NONE }
        b.statusText.text = "A型掃描：ON　B型掃描：ON\n掃描股票：${filteredSource.size}/${source.size}　A:${aCount}　B:${bCount}　新觸發:${newTriggers}　最後更新:${now}"
        render()
    }

    private fun render() {
        val filtered = when(selectedTab) {
            1 -> latest.filter { it.radarType.name.startsWith("A_") && it.light != SignalLight.NONE }
            2 -> latest.filter { it.radarType.name.startsWith("B_") && it.light != SignalLight.NONE }
            3 -> latest.filter { it.score in 65..84 }
            4 -> latest.filter { it.light == SignalLight.WEAKENING }
            else -> latest.filter { it.light == SignalLight.RED || it.light == SignalLight.ORANGE }
        }.sortedByDescending { it.score }
        adapter.submit(filtered)
    }

    private fun loadIndustryFilter() {
        val saved = prefs.getStringSet("enabled_sectors", null)
        enabledSectors = if (saved == null) {
            StockSector.entries.toMutableSet()
        } else {
            saved.mapNotNull { name -> runCatching { StockSector.valueOf(name) }.getOrNull() }.toMutableSet()
        }
        if (enabledSectors.isEmpty()) enabledSectors = StockSector.entries.toMutableSet()
    }

    private fun saveIndustryFilter() {
        prefs.edit().putStringSet("enabled_sectors", enabledSectors.map { it.name }.toSet()).apply()
    }

    private fun updateIndustryFilterButton() {
        val total = StockSector.entries.size
        b.industryFilterButton.text = when (enabledSectors.size) {
            total -> "產業篩選：全部掃描"
            0 -> "產業篩選：未選擇"
            else -> "產業篩選：已選 ${enabledSectors.size}/$total 類"
        }
    }

    private fun showIndustryFilterDialog() {
        val sectors = StockSector.entries
        val labels = sectors.map { it.label }.toTypedArray()
        val checked = BooleanArray(sectors.size) { sectors[it] in enabledSectors }

        MaterialAlertDialogBuilder(this)
            .setTitle("選擇要掃描的產業")
            .setMessage("取消勾選的產業將完全略過，不參與 A/B 評分，也不會觸發通知。例如不想掃描傳產，就取消『傳產』。")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setNeutralButton("全選") { _, _ ->
                enabledSectors = StockSector.entries.toMutableSet()
                saveIndustryFilter()
                updateIndustryFilterButton()
                runScan()
            }
            .setNegativeButton("取消", null)
            .setPositiveButton("套用") { _, _ ->
                val chosen = sectors.filterIndexed { index, _ -> checked[index] }.toMutableSet()
                if (chosen.isNotEmpty()) enabledSectors = chosen
                saveIndustryFilter()
                updateIndustryFilterButton()
                runScan()
            }
            .show()
    }

    private fun notifyNewSignal(r: SignalResult) {
        val nm = getSystemService(NotificationManager::class.java)
        val n = NotificationCompat.Builder(this, "signals")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${r.code} ${r.name} 新觸發")
            .setContentText("${r.radarType.name}｜${r.light.name}｜符合度 ${r.score}%")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify((r.code + r.radarType.name + r.light.name).hashCode(), n)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("signals", "上車雷達訊號", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); history.close(); super.onDestroy() }
}
