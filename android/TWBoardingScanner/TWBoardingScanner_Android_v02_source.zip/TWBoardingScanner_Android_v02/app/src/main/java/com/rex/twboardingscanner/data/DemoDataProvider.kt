package com.rex.twboardingscanner.data

import com.rex.twboardingscanner.domain.StockSnapshot
import com.rex.twboardingscanner.domain.StockSector

/**
 * Prototype provider. Replace with a licensed/reliable TWSE/TPEx/broker/backend provider.
 * Missing fields must remain null/false; never guess missing values.
 */
class DemoDataProvider {
    fun load(): List<StockSnapshot> = listOf(
        StockSnapshot(
            code="1590", name="亞德客-KY", sector=StockSector.ELECTROMECHANICAL, price=1245.0, changePct=2.1,
            volumeLots=1800, avg20VolumeLots=1000.0,
            ma5=1215.0, ma10=1205.0, ma20=1220.0, ma60=1320.0,
            ma5SlopeUp=true, maConverging=true, rsi=53.8, kdOverheated=false,
            dif=-8.0, signal=-10.8, osc=2.8, difRising=true, macdGoldenCross=true,
            macdNegBarsShrinking=true, macdTurnedPositive=false, macdRedExpanding=true,
            foreignToday=120, foreign3d=326, foreign5d=410, trust3d=45, trust5d=70,
            foreignSellingShrinking=true, nearResistance=true, breakoutResistance=true,
            breakoutLine=1240.0, recentHighDistancePct=2.8, high52wDistancePct=-20.0,
            drawdown52wPct=-34.0, noNewLow20to60d=true, lowsRising=true,
            volumeContractingDuringDecline=true, epsTtm=52.0, revenueYoY=18.0,
            fundamentalsDeteriorating=false, fiveDayGainPct=6.0, distanceFromMa20Pct=2.05,
            timestamp=System.currentTimeMillis()
        )
    )
}
