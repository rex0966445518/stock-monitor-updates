package com.rex.twboardingscanner.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.rex.twboardingscanner.domain.SignalResult

class SignalHistoryDb(context: Context): SQLiteOpenHelper(context, "signals.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE signal_history(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, radar TEXT, light TEXT, score INTEGER, reasons TEXT, ts INTEGER, UNIQUE(code, radar, light, reasons))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertIfNew(r: SignalResult): Boolean {
        val reasons = r.reasons.joinToString("+")
        val sql = "INSERT OR IGNORE INTO signal_history(code,radar,light,score,reasons,ts) VALUES(?,?,?,?,?,?)"
        writableDatabase.compileStatement(sql).use { st ->
            st.bindString(1, r.code); st.bindString(2, r.radarType.name); st.bindString(3, r.light.name)
            st.bindLong(4, r.score.toLong()); st.bindString(5, reasons); st.bindLong(6, r.snapshot.timestamp)
            return st.executeInsert() != -1L
        }
    }
}
