package com.rex.twboardingscanner.domain

enum class RadarType { A_EARLY_BREAKOUT, B_DEEP_REVERSAL }
enum class SignalLight { NONE, YELLOW, ORANGE, RED, WEAKENING }

enum class StockSector(val label: String) {
    SEMICONDUCTOR("半導體"),
    ELECTRONICS("電子零組件"),
    AI_SERVER("AI／伺服器"),
    OPTOELECTRONICS("光電"),
    COMMUNICATION("通訊網路"),
    ELECTROMECHANICAL("電機機械"),
    TRADITIONAL("傳產"),
    FINANCE("金融"),
    BIOTECH("生技醫療"),
    SHIPPING("航運"),
    CONSTRUCTION("建材營造"),
    TOURISM_RETAIL("觀光／零售"),
    OTHER("其他")
}

data class StockSnapshot(
    val code: String,
    val name: String,
    val sector: StockSector,
    val price: Double,
    val changePct: Double,
    val volumeLots: Int,
    val avg20VolumeLots: Double,
    val ma5: Double?, val ma10: Double?, val ma20: Double?, val ma60: Double?,
    val ma5SlopeUp: Boolean,
    val maConverging: Boolean,
    val rsi: Double?,
    val kdOverheated: Boolean,
    val dif: Double?, val signal: Double?, val osc: Double?,
    val difRising: Boolean,
    val macdGoldenCross: Boolean,
    val macdNegBarsShrinking: Boolean,
    val macdTurnedPositive: Boolean,
    val macdRedExpanding: Boolean,
    val foreignToday: Int?, val foreign3d: Int?, val foreign5d: Int?,
    val trust3d: Int?, val trust5d: Int?,
    val foreignSellingShrinking: Boolean,
    val nearResistance: Boolean,
    val breakoutResistance: Boolean,
    val breakoutLine: Double?,
    val recentHighDistancePct: Double?,
    val high52wDistancePct: Double?,
    val drawdown52wPct: Double?,
    val noNewLow20to60d: Boolean,
    val lowsRising: Boolean,
    val volumeContractingDuringDecline: Boolean,
    val epsTtm: Double?,
    val revenueYoY: Double?,
    val fundamentalsDeteriorating: Boolean,
    val fiveDayGainPct: Double?,
    val distanceFromMa20Pct: Double?,
    val timestamp: Long
)

data class SignalResult(
    val code: String,
    val name: String,
    val sector: StockSector,
    val radarType: RadarType,
    val score: Int,
    val light: SignalLight,
    val reasons: List<String>,
    val blockers: List<String>,
    val snapshot: StockSnapshot
)
