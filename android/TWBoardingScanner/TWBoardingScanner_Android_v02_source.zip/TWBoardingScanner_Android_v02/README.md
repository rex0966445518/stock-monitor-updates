# 台股上車掃描器 Android v0.2

原生 Kotlin Android 專案。目的：將 A「早期起漲」與 B「深跌反轉」規則做成手機掃描與提醒 APP。

## v0.2 新增
- 產業類別篩選，多選勾選／取消
- 預設全產業掃描
- 取消勾選的產業完全不進 A/B 引擎、也不發通知
- 篩選設定使用 SharedPreferences 保存，重新開啟 APP 仍保留
- 卡片顯示股票所屬產業
- 掃描狀態顯示「實際掃描數／資料來源總數」

內建大類：半導體、電子零組件、AI／伺服器、光電、通訊網路、電機機械、傳產、金融、生技醫療、航運、建材營造、觀光／零售、其他。

## 已完成於此原型
- A/B 雙引擎
- MACD 硬門檻
- 成交量 <500 張阻擋
- 100 分評分架構
- A 型黃色/紅色邏輯
- B 型黃色/橘色/紅色邏輯
- 股票卡片 UI
- 紅燈卡片閃爍
- Android 通知
- SQLite 觸發歷史
- 相同 code/radar/light/reasons 不重複通知
- 每 60 秒掃描迴圈（APP 開啟時）
- 資料不足不得自動視為通過

## 重要：資料來源
目前 `DemoDataProvider` 只放一筆示範資料，**不會假裝是即時市場資料**。
要真正掃描上市＋上櫃，需要替換成正式 `MarketDataProvider`，供應至少：
- 日線歷史 OHLCV（計算 MA / RSI / MACD / KD / 前高 / 52 週回落）
- 盤中價與量
- 外資/投信買賣超
- EPS / 營收 YoY

建議正式版分成：
1. 手機 APP：UI、卡片、通知、歷史、規則結果
2. Scanner API/Backend：抓全市場資料、統一計算指標、避免手機對數千檔股票頻繁打 API

若只要求「APP 開啟時掃描」，可以完全在手機端做；若要求 APP 關閉/螢幕關閉仍持續提醒，建議用後端 + Push，或 Android foreground service。

## 官方資料注意事項
上市/上櫃官方盤後資料與 API 有不同授權/時效；法人、即時行情、基本面也可能分散在不同來源。正式商用前必須確認資料授權與使用條款，不能用網頁爬蟲假裝穩定 API。

## Build
此專案設定：
- minSdk 26
- target/compileSdk 35
- Kotlin
- ViewBinding

在 Android Studio 開啟根目錄，Sync Gradle 後執行 `assembleDebug` 可產生 debug APK。

## 下一版建議 v0.2
- 正式 MarketDataProvider interface + API 設定頁
- A/B 門檻可由 UI 調整
- 黃→橘→紅→轉弱完整狀態機
- 觸發歷史頁
- 回測頁
- 自選股與排除清單
- 背景掃描/Push
- API 快取與斷線恢復
